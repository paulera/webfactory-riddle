<?php

ob_start();
header("Location: /true/false/notpron.php");
ob_end_flush();
